# ExpO Initiative

## ExpOSe: ExpO Server
An API service for performing expainability operators over Ontology Driven Conceptual Models.

### Installation
```shell script
git clone git@gitlab.inf.unibz.it:explanations-in-odcm/expose.git
cp .env.example .env
docker-compose --compatibility up -d
```

### Endpoints
Endpoint documentation is available at `/docs` and `/redoc` endpoints

### Examples of requests
Test if the server is running and accepts requests:
```shell script
[GET] http://host-name:port/health
```

Apply __abstraction__ (aspects and parthood) to the model located in https://purl.org/ontouml-models/fumagalli2022criminal-investigation
```shell script
[POST] http://host-name:port/abstract?atype=aspects&atype=parthood&name=fumagalli2022criminal-investigation
```

