# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['expose', 'expose.project', 'expose.schema']

package_data = \
{'': ['*']}

install_requires = \
['fastapi>=0.95.1,<0.96.0',
 'pygithub>=1.58.1,<2.0.0',
 'python-decouple>=3.8,<4.0',
 'python-multipart>=0.0.6,<0.0.7',
 'requests>=2.28.2,<3.0.0',
 'uvicorn>=0.21.1,<0.22.0']

setup_kwargs = {
    'name': 'expo',
    'version': '0.1.0',
    'description': 'Explanation of ODCM Initiative',
    'long_description': '# ExpO Initiative\n\n## ExpOSe: ExpO Server\nAn API service for performing expainability operators over Ontology Driven Conceptual Models.\n\n### Installation\n```shell script\ngit clone git@gitlab.inf.unibz.it:explanations-in-odcm/expose.git\ncp .env.example .env\ndocker-compose --compatibility up -d\n```\n\n### Endpoints\nEndpoint documentation is available at `/docs` and `/redoc` endpoints\n\n### Examples of requests\nTest if the server is running and accepts requests:\n```shell script\n[GET] http://host-name:port/health\n```\n\nApply __abstraction__ (aspects and parthood) to the model located in https://purl.org/ontouml-models/fumagalli2022criminal-investigation\n```shell script\n[POST] http://host-name:port/abstract?atype=aspects&atype=parthood&name=fumagalli2022criminal-investigation\n```\n\n',
    'author': 'Elena Romanenko',
    'author_email': 'eromanenko@unibz.it',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
